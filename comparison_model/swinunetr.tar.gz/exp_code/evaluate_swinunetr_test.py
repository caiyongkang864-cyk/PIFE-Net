#!/usr/bin/env python3
"""Check segmentation geometry and invoke the installed official nnU-Net evaluator.
Run in the SAME nnU-Net environment used to evaluate the other models.
"""
import os
for key in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS','NUMEXPR_MAX_THREADS'):
    os.environ[key]='1'
import argparse
import json
from pathlib import Path
import subprocess
import sys
import nibabel as nib
import numpy as np

ROOT='/root/autodl-tmp/MRISegmentaterData/MRISegmenter_T1only_public_20Jun2025/Release'

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--pred-dir',default='/root/autodl-tmp/nnUNet/test_predictions/SwinUNETR_5fold_native')
    p.add_argument('--label-dir',default=ROOT+'/labelsTs')
    p.add_argument('--dataset-json',required=True,help='Same label definition as baseline evaluation')
    p.add_argument('--plans',required=True,help='nnU-Net plans.json used for baseline evaluation, NOT a MONAI config')
    p.add_argument('--num-processes',type=int,default=2)
    a=p.parse_args()
    pred,gt=Path(a.pred_dir).resolve(),Path(a.label_dir).resolve()
    for path in (pred,gt):
        if not path.is_dir(): raise FileNotFoundError(path)
    for path in (a.dataset_json,a.plans):
        if not Path(path).is_file(): raise FileNotFoundError(path)
    manifest=pred/'prediction_manifest.json'
    if manifest.exists() and json.loads(manifest.read_text())['status']!='complete':
        raise RuntimeError('Prediction incomplete; do not evaluate a partial run')
    ds=json.loads(Path(a.dataset_json).read_text())
    if ds.get('file_ending')!='.nii.gz':raise ValueError('Expected .nii.gz dataset')
    allowed=set()
    for v in ds['labels'].values():
        allowed.update(v if isinstance(v,list) else [v])
    allowed=sorted(int(x) for x in allowed)
    pn={x.name for x in pred.glob('*.nii.gz')};gn={x.name for x in gt.glob('*.nii.gz')}
    if not gn or pn!=gn:
        raise RuntimeError(f'Missing predictions={sorted(gn-pn)}; extra predictions={sorted(pn-gn)}; GT count={len(gn)}')
    for i,name in enumerate(sorted(gn),1):
        pi,gi=nib.load(str(pred/name)),nib.load(str(gt/name))
        if pi.shape!=gi.shape or len(gi.shape)!=3:
            raise RuntimeError(f'{name}: prediction {pi.shape} vs GT {gi.shape}')
        if not np.allclose(pi.affine,gi.affine,rtol=0,atol=1e-4):
            raise RuntimeError(f'{name}: affine mismatch; fix geometry before evaluating')
        for kind,img in [('prediction',pi),('GT',gi)]:
            arr=np.asarray(img.dataobj)
            if not np.isfinite(arr).all() or not np.isin(np.unique(arr),allowed).all():
                raise RuntimeError(f'{name}: invalid {kind} values; allowed={allowed}')
        print(f'[CHECK {i}/{len(gn)}] {name}',flush=True)
    # Use the current interpreter rather than a potentially unrelated PATH entry point.
    code=('from nnunetv2.evaluation.evaluate_predictions import evaluate_folder_entry_point; '
          'evaluate_folder_entry_point()')
    cmd=[sys.executable,'-c',code,str(gt),str(pred),'-djfile',str(Path(a.dataset_json).resolve()),
         '-pfile',str(Path(a.plans).resolve()),'-o',str(pred/'summary.json'),'-np',str(a.num_processes)]
    subprocess.run(cmd,check=True)
    result=json.loads((pred/'summary.json').read_text())
    print(f"Foreground mean Dice: {result['foreground_mean']['Dice']:.9f}")
    print('Summary:',pred/'summary.json')

if __name__=='__main__':main()
