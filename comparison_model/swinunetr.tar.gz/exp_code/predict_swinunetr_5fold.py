#!/usr/bin/env python3
"""Five-fold mean-probability ensemble using each trained local Swin bundle.
Run in the MONAI environment used for training. No additional TTA is applied.
Local bundles/checkpoints must be trusted. Output must be a new directory.
"""
import os
for key in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS','NUMEXPR_MAX_THREADS'):
    os.environ[key] = '1'
import argparse
import gc
import hashlib
import importlib
import json
from pathlib import Path
import sys
import types
import nibabel as nib
import numpy as np
import torch
import monai
from monai.bundle import ConfigParser

ROOT = '/root/autodl-tmp/MRISegmentaterData/MRISegmenter_T1only_public_20Jun2025/Release'

def sha256(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(8*1024*1024), b''):
            h.update(b)
    return h.hexdigest()

def atomic_json(path, obj):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(obj, indent=2), encoding='utf-8')
    tmp.replace(path)

def load_infer_class(bundle, fold):
    # Unique package names preserve relative imports and isolate per-fold modules.
    name = f'_swin_bundle_fold_{fold}'
    pkg = types.ModuleType(name)
    pkg.__path__ = [str(bundle)]
    sys.modules[name] = pkg
    scripts = types.ModuleType(name + '.scripts')
    scripts.__path__ = [str(bundle / 'scripts')]
    sys.modules[name + '.scripts'] = scripts
    return importlib.import_module(name + '.scripts.infer').InferClass

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--work-dir', required=True, help='Absolute training workspace containing swinunetr_0 ... swinunetr_4')
    ap.add_argument('--images', default=ROOT+'/imagesTs')
    ap.add_argument('--output', default='/root/autodl-tmp/nnUNet/test_predictions/SwinUNETR_5fold_native')
    ap.add_argument('--sw-batch-size', type=int, default=1, help='Sliding-window batch size; 1 saves GPU memory')
    ap.add_argument('--checkpoint-relative', help='Optional existing checkpoint path relative to EACH fold bundle. Default: infer.ckpt_name from its config')
    ap.add_argument('--check-only', action='store_true', help='Resolve all configs/checkpoints without predicting or creating output')
    args = ap.parse_args()
    if args.sw_batch_size < 1:
        raise ValueError('--sw-batch-size must be positive')
    work, images_dir, out = (Path(p).resolve() for p in (args.work_dir,args.images,args.output))
    images = sorted(images_dir.glob('*.nii.gz'))
    if not images:
        raise RuntimeError(f'No NIfTI inputs in {images_dir}')
    def result_name(p):
        return p.name[:-len('_0000.nii.gz')]+'.nii.gz' if p.name.endswith('_0000.nii.gz') else p.name
    names = [result_name(p) for p in images]
    if len(set(names)) != len(names):
        raise RuntimeError('Duplicate output case names after removing _0000')
    if out.exists() and any(out.iterdir()):
        raise RuntimeError(f'Output is not empty: {out}. Choose a NEW output directory.')
    jobs = []
    nclasses = None
    for fold in range(5):
        bundle = work / f'swinunetr_{fold}'
        configs = sorted(p for p in (bundle/'configs').glob('*')
                         if p.is_file() and not p.name.startswith('.') and p.suffix.lower() in ('.yaml','.yml','.json'))
        if not (bundle/'scripts/infer.py').is_file() or not configs:
            raise FileNotFoundError(f'Missing Swin bundle/scripts/configs: {bundle}')
        parser = ConfigParser()
        parser.read_config([str(p) for p in configs])
        parser.update({'bundle_root':str(bundle), 'auto_scale_allowed':False})
        if not parser.get_parsed_content('softmax'):
            raise RuntimeError('This script requires multiclass softmax segmentation')
        nc = int(parser.get_parsed_content('output_classes'))
        if nclasses is not None and nc != nclasses:
            raise RuntimeError('Folds have different output class counts')
        nclasses = nc
        if args.checkpoint_relative:
            rel = Path(args.checkpoint_relative)
            if rel.is_absolute() or '..' in rel.parts:
                raise ValueError('--checkpoint-relative must stay inside each fold bundle')
            ckpt = bundle / rel
        else:
            ckpt = Path(parser.get_parsed_content('infer#ckpt_name'))
            if not ckpt.is_absolute():
                ckpt = bundle / ckpt
        ckpt = ckpt.resolve()
        if not ckpt.is_relative_to(bundle.resolve()):
            raise RuntimeError(f'Checkpoint points outside current fold: {ckpt}. Supply --checkpoint-relative with the correct local path.')
        if not ckpt.is_file():
            raise FileNotFoundError(ckpt)
        jobs.append((fold,bundle,configs,ckpt))
        print(f'[FOLD {fold}] checkpoint={ckpt}', flush=True)
        print('  roi_size_valid=',parser.get_parsed_content('roi_size_valid'),
              ' overlap_ratio_final=',parser.get_parsed_content('overlap_ratio_final'),flush=True)
    print(f'MONAI={monai.__version__}; cases={len(images)}; classes={nclasses}; folds=0,1,2,3,4',flush=True)
    print('Ensemble: mean of restored probabilities; additional TTA: NONE; local infer.py behavior is retained.',flush=True)
    if args.check_only:
        return
    if not torch.cuda.is_available():
        raise RuntimeError('CUDA unavailable; run in the training MONAI environment')
    out.mkdir(parents=True,exist_ok=True)
    runtime = out / '_runtime'
    runtime.mkdir()
    datalist = runtime / 'testing.json'
    atomic_json(datalist, {'testing':[{'image':str(p)} for p in images]})
    manifest = {'status':'running','monai_version':monai.__version__,'work_dir':str(work),
                'images':str(images_dir),'cases':names,'additional_tta':False,
                'ensemble':'mean probabilities after spatial inversion','checkpoints':[], 'completed':0}
    for fold,bundle,configs,ckpt in jobs:
        manifest['checkpoints'].append({'fold':fold,'path':str(ckpt),'sha256':sha256(ckpt),
            'config_sha256':{p.name:sha256(p) for p in configs},
            'infer_py_sha256':sha256(bundle/'scripts/infer.py')})
    atomic_json(out/'prediction_manifest.json',manifest)
    classes = [load_infer_class(bundle,fold) for fold,bundle,_,_ in jobs]
    # Load one model at a time per case: low model-memory usage, at the cost of repeated checkpoint I/O.
    for index,(image_path,name) in enumerate(zip(images,names),1):
        ref = nib.load(str(image_path))
        if len(ref.shape)!=3:
            raise RuntimeError(f'Expected 3D single-channel image: {image_path}: {ref.shape}')
        acc = None
        for cls,(fold,bundle,configs,ckpt) in zip(classes,jobs):
            foldout = runtime/f'fold_{fold}'
            foldout.mkdir(exist_ok=True)
            override = {'bundle_root':str(bundle),'auto_scale_allowed':False,
                'data_file_base_dir':str(images_dir),'data_list_file_path':str(datalist),
                'num_sw_batch_size':args.sw_batch_size,'infer#fast':False,
                'infer#ckpt_name':str(ckpt),'infer#data_list_key':'testing',
                'infer#output_path':str(foldout),'infer#log_output_file':str(foldout/'infer.log')}
            inferer = cls(config_file=[str(p) for p in configs], **override)
            with torch.inference_mode():
                pred = inferer.infer({'image':str(image_path)}, save_mask=False)
            if not isinstance(pred,torch.Tensor) or tuple(pred.shape)!=(nclasses,*ref.shape):
                raise RuntimeError(f'Fold {fold}: unexpected probability shape {getattr(pred,"shape",None)}')
            affine = getattr(pred,'affine',None)
            if affine is None:
                raise RuntimeError('Missing output spatial metadata; cannot verify inversion')
            affine = torch.as_tensor(affine).detach().cpu().numpy()
            if not np.allclose(affine,ref.affine,rtol=0,atol=1e-4):
                raise RuntimeError(f'Fold {fold}: restored affine differs from input; stopping instead of resampling silently')
            probs = pred.detach().to(device='cpu',dtype=torch.float32)
            if hasattr(probs,'as_tensor'):
                probs = probs.as_tensor()
            if not torch.isfinite(probs).all() or probs.min() < -1e-5 or probs.max()>1.00001:
                raise RuntimeError('Invalid probability values')
            if acc is None:
                acc=probs.clone()
            else:
                acc.add_(probs)
            del probs,pred,inferer
            gc.collect()
            torch.cuda.empty_cache()
        mask = (acc/5).argmax(dim=0).numpy().astype(np.uint8 if nclasses<=256 else np.uint16)
        header = ref.header.copy()
        header.set_data_dtype(mask.dtype)
        nii = nib.Nifti1Image(mask,ref.affine,header)
        nii.set_qform(ref.get_qform(),int(ref.header['qform_code']))
        nii.set_sform(ref.get_sform(),int(ref.header['sform_code']))
        temp = out/(name[:-7]+'.partial.nii.gz')
        nib.save(nii,str(temp))
        temp.replace(out/name)
        del acc,mask,nii
        manifest['completed']=index
        atomic_json(out/'prediction_manifest.json',manifest)
        print(f'[SAVED {index}/{len(images)}] {out/name}',flush=True)
    manifest['status']='complete'
    atomic_json(out/'prediction_manifest.json',manifest)
    print('Completed:',out,flush=True)

if __name__=='__main__':
    main()
