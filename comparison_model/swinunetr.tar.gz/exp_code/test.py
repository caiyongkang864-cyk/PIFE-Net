import json
import os

# 1. 你的 MONAI dataset.json 路径
monai_json_path = "/root/exp_code/mri_workspace/dataset.json"

# 2. 你的 nnU-Net splits_final.json 路径 (请替换为实际路径)
# 通常在 nnUNet_preprocessed/DatasetXXX_MRISegmenter/splits_final.json
nnunet_splits_path = "/root/autodl-tmp/nnUNet/nnUNet_preprocessed/Dataset129_1CH/splits_final.json" 

def verify_splits():
    # 读取 MONAI 格式的 json
    with open(monai_json_path, "r") as f:
        monai_data = json.load(f)
        
    # 读取 nnU-Net 格式的 json
    with open(nnunet_splits_path, "r") as f:
        nnunet_splits = json.load(f)

    # 提取 nnU-Net Fold 0 的验证集名单
    # nnU-Net 的名单通常只包含纯 ID，比如 "case_0001"
    nnunet_val_fold0 = set(nnunet_splits[0]['val'])
    
    # 提取 MONAI 中 fold: 0 的验证集名单
    monai_val_fold0 = set()
    for item in monai_data["training"]:
        if item.get("fold") == 0:
            # 从绝对路径中提取出纯 ID，确保和 nnU-Net 的格式一致
            # 根据你的实际文件名提取，这里假设文件名是 case_0001.nii.gz
            file_name = os.path.basename(item["image"]) 
            case_id = file_name.replace(".nii.gz", "").replace("_0000", "")
            monai_val_fold0.add(case_id)

    # 进行终极断言比对
    print(f"nnU-Net Fold 0 验证集数量: {len(nnunet_val_fold0)}")
    print(f"MONAI   Fold 0 验证集数量: {len(monai_val_fold0)}")
    
    if nnunet_val_fold0 == monai_val_fold0:
        print("\n✅ 完美对齐！两个框架的 Fold 0 验证集病例 100% 相同，没有任何数据泄露！")
    else:
        print("\n❌ 警告：划分不一致！")
        print("MONAI 多出的病例:", monai_val_fold0 - nnunet_val_fold0)
        print("nnU-Net 多出的病例:", nnunet_val_fold0 - monai_val_fold0)

if __name__ == "__main__":
    verify_splits()