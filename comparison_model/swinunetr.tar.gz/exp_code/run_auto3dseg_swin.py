import os
from monai.apps.auto3dseg import AutoRunner

# 1. 定义工作目录和数据路径
work_dir = "./mri_workspace"  
dataroot = "/root/autodl-tmp/MRISegmentaterData/MRISegmenter_T1only_public_20Jun2025/Release" # 替换为你的真实绝对路径

# 2. 配置 AutoRunner
runner = AutoRunner(
    work_dir=work_dir,
    input={
        "modality": "MRI",             
        "datalist": "dataset.json", # 我们刚才带有 fold 划分的 JSON
        "dataroot": dataroot           
    },
    algos=["swinunetr"]  # <-- 核心修改点 1：只指定生成并训练 Swin-UNETR
)
# 修改后的配置
# 降时提效配置方案
train_param = {
    "use_pretrain": True,        # 满血启动
    
    # 严谨评估后的黄金轮次：完美覆盖 1.4 万次迭代，适应 62 分类
    "num_epochs": 200,           
    
    # 高频验证，确保在 80-150 轮之间随时捕获巅峰模型
    "val_interval": 10,          
    
    "num_images_per_batch": 6,   
    "num_sw_batch_size": 8       
}

# 3. 设置交叉验证折数
runner.set_num_fold(num_fold=5) # <-- 核心修改点 2：强制跑满 Fold 0 到 Fold 4
runner.set_training_params(params=train_param)

# 4. 一键启动
if __name__ == "__main__":
    runner.run()