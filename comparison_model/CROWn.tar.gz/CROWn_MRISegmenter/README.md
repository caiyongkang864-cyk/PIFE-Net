# CROWn on MRISegmenter W-only

This standalone adaptation uses the uploaded `networks/CROWn.py` network. It
uses nnU-Net's existing Dataset129_1CH preprocessing and exact five-fold
`splits_final.json`. It does **not** use nnU-Net's training data augmentation,
deep supervision, trainer, or loss. The original archive lacks `model.py`,
which its original `train.py` requires, and hard-codes 96-cubed ROI and CT
intensity scaling. Here the model and batch protocol are kept, while patch
sampling and MRI augmentation are provided in `data_mri.py`.

Three implementation fixes in `crown_model.py`:

1. A wavelet projection convolution created in `forward` is now registered in
   `__init__`, making it trainable, checkpointed and deterministic at inference.
2. Grouped DWT output is reshaped per channel before LL/LH/HL/HH splitting.
3. Attention's explicit quadratic matrix is computed using PyTorch SDPA, the
   mathematically corresponding scaled dot product attention (minor numerical
   differences possible), for memory efficiency.

The standalone experiment uses AdamW at 1e-4, Dice+CE ignoring -1 voxels,
BF16 autocast, 1000 epochs, 250 train/50 validation iterations per epoch,
batch=2, patch=(48,160,192). Epoch-wise 50-batch pseudo-Dice selects the best
checkpoint. This is an adaptation, **not** an exact reproduction of the paper
or a single-variable architecture ablation against nnU-Net.

## Setup on your training machine

```bash
cd /root/CROWn_MRISegmenter
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
python -m pip install -r requirements-extra.txt
CUDA_VISIBLE_DEVICES=0 python smoke_mri.py --precision bf16
```

Only if the full patch smoke test passes and memory allows:

```bash
CUDA_VISIBLE_DEVICES=0 python train_mri.py 0
CUDA_VISIBLE_DEVICES=0 python train_mri.py 0 --resume
CUDA_VISIBLE_DEVICES=0 bash run_folds.sh
```

To test compilation, run `python smoke_mri.py --compile` **before**
`python train_mri.py 0 --compile` (each fold has separate checkpoints).
Checkpoint paths are `.../CROWn_native_results/fold_N/checkpoint_best.pt` and
`checkpoint_latest.pt`. Do not mix checkpoints from different source versions.

`smoke_mri.py` checks random input only. There has been no GPU validation of
this code in the authoring environment. The actual 32-GB memory use and epoch
duration must be established on the target GPU.
