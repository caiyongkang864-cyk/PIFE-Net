#!/usr/bin/env python3
"""One full-resolution update and validation; exits on OOM, NaN, shape error."""
import argparse
import time

import torch

from data_mri import PATCH
from train_mri import CLASSES, autocast_for, create_model, dice_counts, segmentation_loss


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--precision", choices=("bf16", "fp32"), default="bf16")
    parser.add_argument("--compile", action="store_true")
    args = parser.parse_args()
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA GPU required")
    torch.set_num_threads(1)
    torch.set_float32_matmul_precision("high")
    torch.manual_seed(42)
    device = torch.device("cuda:0")
    model = create_model(args.compile).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4)
    x = torch.randn((2, 1, *PATCH), device=device)
    y = torch.randint(CLASSES, (2, *PATCH), device=device)
    torch.cuda.reset_peak_memory_stats()
    t = time.perf_counter()
    model.train()
    optimizer.zero_grad(set_to_none=True)
    with autocast_for(device, args.precision):
        logits = model(x)
        loss = segmentation_loss(logits, y)
    assert logits.shape == (2, CLASSES, *PATCH)
    assert torch.isfinite(loss).item()
    loss.backward()
    norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 12, error_if_nonfinite=True)
    optimizer.step()
    torch.cuda.synchronize()
    elapsed = time.perf_counter() - t
    print(f"Train: shape={tuple(logits.shape)}, loss={loss.item():.5f}, "
          f"grad_norm={norm.item():.5f}, time={elapsed:.3f}s, "
          f"peak_allocated_GiB={torch.cuda.max_memory_allocated()/2**30:.2f}, "
          f"peak_reserved_GiB={torch.cuda.max_memory_reserved()/2**30:.2f}", flush=True)
    del logits, loss, norm
    t = time.perf_counter()
    model.eval()
    with torch.inference_mode(), autocast_for(device, args.precision):
        logits = model(x)
        loss = segmentation_loss(logits, y)
        counts = dice_counts(logits, y)
    torch.cuda.synchronize()
    print(f"Validation: shape={tuple(logits.shape)}, loss={loss.item():.5f}, "
          f"counts={counts.shape}, time={time.perf_counter()-t:.3f}s", flush=True)
    print("PASS: synthetic smoke test; speed and convergence on real data are unverified.")


if __name__ == "__main__":
    main()
