"""Read nnU-Net's existing preprocessed 3D cases, sample fixed-size patches.

This does not alter the raw data, labels, or split file. The preprocessing
remains the already generated Dataset129_1CH nnUNetPlans_3d_fullres.
"""
import json
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import IterableDataset, get_worker_info
from nnunetv2.training.dataloading.nnunet_dataset import infer_dataset_class


PATCH = (48, 160, 192)


def get_folds(split_file: Path, fold: int):
    folds = json.loads(split_file.read_text())
    if fold not in range(len(folds)):
        raise ValueError(f"fold must be in [0,{len(folds)-1}]")
    train = list(folds[fold]["train"])
    val = list(folds[fold]["val"])
    if not train or not val or set(train) & set(val):
        raise ValueError("Invalid or overlapping train/validation splits")
    return train, val


def load_case(reader, identifier: str):
    # nnU-Net v2 chooses Numpy / Blosc2 / other storage through the same API.
    data, seg, _, _ = reader.load_case(identifier)
    data, seg = np.asarray(data[:]), np.asarray(seg[:])
    if data.ndim != 4 or data.shape[0] != 1:
        raise ValueError(f"Expected one W channel: {identifier}, {data.shape}")
    if seg.ndim == 4 and seg.shape[0] == 1:
        seg = seg[0]
    if seg.shape != data.shape[1:]:
        raise ValueError(f"Data/label mismatch: {identifier}, {data.shape}, {seg.shape}")
    return data, seg


def extract_patch(data, seg, rng, foreground, patch=PATCH):
    shape = np.array(seg.shape)
    size = np.array(patch)
    if foreground:
        labels = np.unique(seg)
        labels = labels[(labels > 0) & (labels < 63)]
        if len(labels):
            label = int(rng.choice(labels))
            locations = np.argwhere(seg == label)
            center = locations[int(rng.integers(len(locations)))]
            starts = center - np.array([int(rng.integers(max(1, p))) for p in size])
        else:
            starts = np.array([int(rng.integers(-p // 2, max(s - p // 2, 1)))
                               for s, p in zip(shape, size)])
    else:
        starts = np.array([int(rng.integers(-p // 2, max(s - p // 2, 1)))
                           for s, p in zip(shape, size)])
    src_lo = np.maximum(starts, 0)
    src_hi = np.minimum(starts + size, shape)
    dst_lo = src_lo - starts
    dst_hi = dst_lo + src_hi - src_lo
    img = np.zeros((1, *patch), dtype=np.float32)
    target = np.full(patch, -1, dtype=np.int64)
    src = tuple(slice(int(a), int(b)) for a, b in zip(src_lo, src_hi))
    dst = tuple(slice(int(a), int(b)) for a, b in zip(dst_lo, dst_hi))
    img[(slice(None), *dst)] = data[(slice(None), *src)]
    target[dst] = seg[src]
    if np.any((target < -1) | (target > 62)):
        raise ValueError("Expected labels -1 (ignore), 0..62")
    return img, target


class PatchStream(IterableDataset):
    def __init__(self, folder, identifiers, train, seed=42, samples=100, patch=PATCH):
        self.folder = Path(folder)
        self.ids = list(identifiers)
        self.train = train
        self.seed = seed
        self.samples = samples
        self.patch = patch
        self.epoch = 0
        self.dataset_class = infer_dataset_class(str(self.folder))
        available = set(self.dataset_class.get_identifiers(str(self.folder)))
        missing = set(self.ids) - available
        if missing:
            raise FileNotFoundError(f"Missing preprocessed cases: {sorted(missing)[:5]}")

    def set_epoch(self, epoch):
        self.epoch = epoch

    def __iter__(self):
        worker = get_worker_info()
        wid = worker.id if worker else 0
        workers = worker.num_workers if worker else 1
        rng = np.random.default_rng(self.seed + 100003 * self.epoch + wid)
        ids = list(self.ids)
        np.random.default_rng(self.seed + 100003 * self.epoch).shuffle(ids)
        reader = self.dataset_class(str(self.folder), self.ids)
        cached_id, cached_data, cached_seg = None, None, None
        for index in range(wid, self.samples, workers):
            identifier = ids[index % len(ids)] if not self.train else ids[int(rng.integers(len(ids)))]
            if identifier != cached_id:
                cached_data, cached_seg = load_case(reader, identifier)
                cached_id = identifier
            img, target = extract_patch(cached_data, cached_seg, rng,
                                        foreground=self.train and rng.random() < 0.33,
                                        patch=self.patch)
            if self.train:
                for axis in range(3):
                    if rng.random() < 0.5:
                        img = np.flip(img, axis=axis + 1)
                        target = np.flip(target, axis=axis)
                if rng.random() < 0.15:
                    img = img * np.float32(rng.uniform(0.9, 1.1)) + np.float32(rng.uniform(-0.1, 0.1))
            yield {"image": torch.from_numpy(np.ascontiguousarray(img)),
                   "label": torch.from_numpy(np.ascontiguousarray(target))}
