CUDA_VISIBLE_DEVICES=0 python train_mri.py 0
CUDA_VISIBLE_DEVICES=0 python train_mri.py 1
CUDA_VISIBLE_DEVICES=0 python train_mri.py 2
CUDA_VISIBLE_DEVICES=0 python train_mri.py 3
CUDA_VISIBLE_DEVICES=0 python train_mri.py 4