#!/usr/bin/env python3
"""CROWn on MRISegmenter W-only; standalone trainer, existing nnU-Net preprocessing.

Five independent folds; 1000 epochs, 250 training and 50 validation batches per
epoch, batch size 2 and (48,160,192) patches. Run smoke_mri.py first.
"""
import argparse
import contextlib
import json
import os
import random
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader

from crown_model import CROWn
from data_mri import PATCH, PatchStream, get_folds


CLASSES = 63
DEFAULT_DATASET = Path("/root/autodl-tmp/nnUNet/nnUNet_preprocessed/Dataset129_1CH")
DEFAULT_RESULTS = Path("/root/autodl-tmp/nnUNet/CROWn_native_results")


def segmentation_loss(logits, target):
    """Dice + CE, no background Dice, excluding nnU-Net's -1 ignored voxels."""
    if logits.shape[1] != CLASSES or logits.shape[2:] != target.shape[1:]:
        raise ValueError(f"Unexpected logits {tuple(logits.shape)}, target {tuple(target.shape)}")
    with torch.autocast(device_type=logits.device.type, enabled=False):
        logits = logits.float()
        valid = target >= 0
        if not bool(valid.any().item()):
            raise ValueError("Patch contains no valid labels")
        ce = F.cross_entropy(logits, target.long(), ignore_index=-1)
        probabilities = torch.softmax(logits, dim=1)
        truth = F.one_hot(target.long().clamp_min(0), CLASSES).movedim(-1, 1).float()
        valid_mask = valid.unsqueeze(1)
        probabilities = probabilities * valid_mask
        truth = truth * valid_mask
        dims = (0, 2, 3, 4)
        intersection = (probabilities * truth).sum(dims)
        denominator = probabilities.sum(dims) + truth.sum(dims)
        dice = 1 - ((2 * intersection + 1e-5) / (denominator + 1e-5))[1:].mean()
        return ce + dice


def dice_counts(logits, target):
    with torch.no_grad():
        valid = target >= 0
        actual = target[valid].long()
        prediction = logits.argmax(1)[valid].long()
        intersection = torch.bincount(actual[actual == prediction], minlength=CLASSES)
        pred_count = torch.bincount(prediction, minlength=CLASSES)
        true_count = torch.bincount(actual, minlength=CLASSES)
        return torch.stack((intersection, pred_count, true_count), dim=0).cpu().numpy()


def autocast_for(device, precision):
    return torch.autocast("cuda", dtype=torch.bfloat16) if device.type == "cuda" and precision == "bf16" \
        else contextlib.nullcontext()


def create_model(compile_model=False):
    model = CROWn(spatial_dims=3, in_channels=1, out_channels=CLASSES)
    if compile_model:
        model = torch.compile(model, mode="default", dynamic=False)
    return model


def raw_model(model):
    return getattr(model, "_orig_mod", model)


def loader(stream, workers):
    return DataLoader(stream, batch_size=2, num_workers=workers, pin_memory=True,
                      persistent_workers=False, drop_last=True)


def atomic_checkpoint(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    torch.save(payload, temp)
    os.replace(temp, path)


def train(args):
    if not torch.cuda.is_available():
        raise RuntimeError("This training configuration requires one CUDA GPU")
    if args.workers < 0 or args.fold not in range(5):
        raise ValueError("fold must be 0..4 and workers must be >=0")
    torch.set_num_threads(1)
    random.seed(args.seed + args.fold)
    np.random.seed(args.seed + args.fold)
    torch.manual_seed(args.seed + args.fold)
    torch.cuda.manual_seed_all(args.seed + args.fold)
    torch.backends.cudnn.benchmark = True
    torch.set_float32_matmul_precision("high")
    device = torch.device("cuda:0")
    dataset = args.dataset
    folder = dataset / "nnUNetPlans_3d_fullres"
    train_ids, val_ids = get_folds(dataset / "splits_final.json", args.fold)
    if len(train_ids) != 432 or len(val_ids) != 108:
        raise ValueError(f"Unexpected split sizes: {len(train_ids)} train, {len(val_ids)} val")
    output = args.output / f"fold_{args.fold}"
    last = output / "checkpoint_latest.pt"
    if not args.resume and output.exists() and any(output.iterdir()):
        raise RuntimeError(f"Output already contains files: {output}; pass --resume to continue")
    if args.resume and not last.is_file():
        raise FileNotFoundError(f"Cannot resume: {last}")
    output.mkdir(parents=True, exist_ok=True)
    # Multiples of (batch_size * default workers), with surplus complete batches.
    train_stream = PatchStream(folder, train_ids, True, args.seed + args.fold, 512, PATCH)
    val_stream = PatchStream(folder, val_ids, False, args.seed + args.fold, 112, PATCH)
    train_loader = loader(train_stream, args.workers)
    val_loader = loader(val_stream, args.workers)
    model = create_model(args.compile).to(device)
    optimizer = torch.optim.AdamW(raw_model(model).parameters(), lr=args.lr)
    start_epoch, best_dice = 0, -1.0
    if args.resume:
        state = torch.load(last, map_location="cpu", weights_only=False)
        if state.get("fold") != args.fold or state.get("precision") != args.precision:
            raise RuntimeError("Checkpoint fold/precision mismatch")
        raw_model(model).load_state_dict(state["model"])
        optimizer.load_state_dict(state["optimizer"])
        start_epoch = state["epoch"] + 1
        best_dice = state["best_dice"]
    print(f"CROWn fold {args.fold}: train={len(train_ids)}, val={len(val_ids)}, "
          f"epoch={start_epoch}..999, train=250, val=50, batch=2, patch={PATCH}; "
          f"params={sum(p.numel() for p in raw_model(model).parameters()):,}, "
          f"AdamW lr={args.lr}, Dice+CE, precision={args.precision}, compile={args.compile}", flush=True)

    log_path = output / "history.jsonl"
    for epoch in range(start_epoch, 1000):
        tic = time.perf_counter()
        train_stream.set_epoch(epoch)
        val_stream.set_epoch(epoch)
        model.train()
        running_train = 0.0
        train_iter = iter(train_loader)
        for step in range(250):
            batch = next(train_iter)
            image = batch["image"].to(device, non_blocking=True)
            label = batch["label"].to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            with autocast_for(device, args.precision):
                logits = model(image)
                loss = segmentation_loss(logits, label)
            if not bool(torch.isfinite(loss).item()):
                raise FloatingPointError(f"Nonfinite loss fold={args.fold}, epoch={epoch}, step={step}")
            loss.backward()
            torch.nn.utils.clip_grad_norm_(raw_model(model).parameters(), 12, error_if_nonfinite=True)
            optimizer.step()
            running_train += float(loss.detach())
        del train_iter
        model.eval()
        running_val = 0.0
        counts = np.zeros((3, CLASSES), dtype=np.int64)
        with torch.inference_mode():
            val_iter = iter(val_loader)
            for step in range(50):
                batch = next(val_iter)
                image = batch["image"].to(device, non_blocking=True)
                label = batch["label"].to(device, non_blocking=True)
                with autocast_for(device, args.precision):
                    logits = model(image)
                    loss = segmentation_loss(logits, label)
                if not bool(torch.isfinite(loss).item()):
                    raise FloatingPointError(f"Nonfinite validation fold={args.fold}, epoch={epoch}, step={step}")
                running_val += float(loss)
                counts += dice_counts(logits, label)
            del val_iter
        denom = counts[1, 1:] + counts[2, 1:]
        per_class = np.divide(2 * counts[0, 1:], denom, out=np.full(62, np.nan), where=denom > 0)
        pseudo_dice = float(np.nanmean(per_class))
        row = {"fold": args.fold, "epoch": epoch, "train_loss": running_train / 250,
               "val_loss": running_val / 50, "pseudo_dice": pseudo_dice,
               "lr": optimizer.param_groups[0]["lr"], "seconds": time.perf_counter() - tic,
               "peak_reserved_GiB": torch.cuda.max_memory_reserved() / 2 ** 30}
        print(json.dumps(row), flush=True)
        with log_path.open("a") as f:
            f.write(json.dumps(row) + "\n")
        if pseudo_dice > best_dice:
            best_dice = pseudo_dice
            atomic_checkpoint(output / "checkpoint_best.pt", {
                "model": raw_model(model).state_dict(), "epoch": epoch, "fold": args.fold,
                "best_dice": best_dice, "precision": args.precision,
            })
        atomic_checkpoint(last, {
            "model": raw_model(model).state_dict(), "optimizer": optimizer.state_dict(),
            "epoch": epoch, "fold": args.fold, "best_dice": best_dice,
            "precision": args.precision,
        })


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("fold", type=int, choices=range(5))
    parser.add_argument("--dataset", type=Path, default=DEFAULT_DATASET)
    parser.add_argument("--output", type=Path, default=DEFAULT_RESULTS)
    parser.add_argument("--precision", choices=("bf16", "fp32"), default="bf16")
    parser.add_argument("--compile", action="store_true")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--lr", type=float, default=1e-4)
    args = parser.parse_args()
    train(args)


if __name__ == "__main__":
    main()
