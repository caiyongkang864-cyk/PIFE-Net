"""Check full MRISegmenter patch, backward pass and GPU memory."""
import argparse
import time

import torch

from nnunetv2.training.nnUNetTrainer.nnUNetTrainer_SegMambaV2_1000ep import (
    SegMambaV2CrossEntropy,
    nnUNetTrainer_SegMambaV2_1000ep,
)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--compile', action='store_true')
    args = parser.parse_args()
    if not torch.cuda.is_available():
        raise RuntimeError('CUDA GPU required')
    device = torch.device('cuda:0')
    network = nnUNetTrainer_SegMambaV2_1000ep.build_network_architecture(
        None, None, 1, 63, False
    ).to(device).train()
    if args.compile:
        print('Compiling; first forward/backward may take several minutes.', flush=True)
        network = torch.compile(network)
    optimizer = torch.optim.SGD(network.parameters(), lr=0.01, momentum=0.99,
                                nesterov=True, weight_decay=3e-5)
    scaler = torch.amp.GradScaler('cuda')
    loss_fn = SegMambaV2CrossEntropy()
    x = torch.randn(2, 1, 48, 160, 192, device=device)
    y = torch.randint(0, 63, (2, 1, 48, 160, 192), device=device)
    torch.cuda.reset_peak_memory_stats(device)
    for step in range(2):
        started = time.perf_counter()
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast('cuda'):
            logits = network(x)
            loss = loss_fn(logits, y)
        if logits.shape != (2, 63, 48, 160, 192) or not torch.isfinite(loss).item():
            raise RuntimeError(f'Unexpected output/loss: {tuple(logits.shape)} {loss.item()}')
        scaler.scale(loss).backward()
        scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(network.parameters(), 12)
        scaler.step(optimizer)
        scaler.update()
        torch.cuda.synchronize(device)
        print(f'Step {step}: loss={loss.detach().item():.5f}, '
              f'time={time.perf_counter()-started:.2f}s, '
              f'peak_allocated_GiB={torch.cuda.max_memory_allocated(device)/2**30:.2f}, '
              f'peak_reserved_GiB={torch.cuda.max_memory_reserved(device)/2**30:.2f}',
              flush=True)
    print('PASS: output=(2,63,48,160,192), backward and optimizer update. '
          'Random data do not test convergence.')


if __name__ == '__main__':
    main()
