"""Install the source network and trainer into the currently imported nnU-Net."""
import importlib
import inspect
import shutil
from pathlib import Path

from nnunetv2.training.nnUNetTrainer.nnUNetTrainer import nnUNetTrainer


def main():
    source = Path(__file__).resolve().parent
    destination = Path(inspect.getfile(nnUNetTrainer)).resolve().parent
    signature = inspect.signature(nnUNetTrainer.build_network_architecture)
    required = ('plans_manager', 'configuration_manager', 'num_input_channels', 'num_output_channels')
    if tuple(signature.parameters)[:4] != required:
        raise RuntimeError(f'Incompatible nnU-Net API: {signature}')
    name = 'nnUNetTrainer_SegMambaV2_1000ep.py'
    shutil.copy2(source / name, destination / name)
    shutil.copytree(source / 'segmambav2_original', destination / '_segmambav2_original', dirs_exist_ok=True)
    importlib.invalidate_caches()
    from nnunetv2.training.nnUNetTrainer.nnUNetTrainer_SegMambaV2_1000ep import nnUNetTrainer_SegMambaV2_1000ep
    print('Installed trainer:', inspect.getfile(nnUNetTrainer_SegMambaV2_1000ep))
    print('Installed original network:', destination / '_segmambav2_original')


if __name__ == '__main__':
    main()
