# SegMamba-V2 original network on nnU-Net v2 / MRISegmenter

`segmambav2_original/segmambav2.py` is a byte-identical copy of the author's
**colorectal** `models_segmamba/segmambav2.py`, the same file used in the
previous native MRISegmenter training package. This package does not alter
the network's Mamba directions, strides, channel widths, depths, kernel sizes
or decoder. It changes only `in_chans=1`, `out_chans=63` (already done by the
previous native adaptation) and the surrounding training integration.

**Patch `(48,160,192)` does not change the module graph.** There is no fixed
`img_size` or shape-dependent parameter in the model constructor; the network
flattens current feature-map shapes at runtime. Four stride-2 convolutions
yield `(24,80,96)`, `(12,40,48)`, `(6,20,24)`, `(3,10,12)`; the patch is
divisible by 16 on each axis. It *does* change Mamba token lengths, spatial
context, activation memory and speed compared with the upstream colorectal
script's `(128,128,128)` patch.

## Comparison protocol

Uses unchanged `nnUNetPlans` and `splits_final.json` for Dataset129_1CH:
W-only, 63 labels, patch `(48,160,192)`, batch 2, 1000 epochs, 250 training
and 50 validation iterations per epoch, one GPU. Official colorectal SGD
`lr=0.01`, `momentum=0.99`, `nesterov=True`, `weight_decay=3e-5`, CE loss,
AMP and clipping at 12 are retained. Poly decay with exponent `0.9` is
applied after each train batch; on checkpoint resume the absolute update
number is reconstructed from epoch and batch index.

Training uses nnU-Net's preprocessed cases, foreground patch sampling,
augmentation, validation and checkpoints. Thus it is a **shared-data
protocol method comparison** with nnU-Net, but differs from the previous
native SegMamba-V2 run in data augmentation, validation and checkpoint
selection. Do not mix their checkpoints or folds.

`torch.compile` is **off by default** because Mamba's custom CUDA kernels
can cause graph breaks and excessive recompilation. If requested, set
`nnUNet_compile=true` and run `python benchmark.py --compile` before training;
compile does not change the network weights/layers, but may alter runtime and
memory use. The source network requires the working `mamba_ssm` and
`causal_conv1d` CUDA extensions compatible with the selected PyTorch.

## Setup and run

Activate the same conda environment that successfully ran native SegMamba-V2.
Check that both its dependencies and nnU-Net v2 import in *that* environment:

```bash
cd /root/SegMambaV2_nnUNet_MRISegmenter_1000ep
python -c 'import torch, monai, einops, mamba_ssm, nnunetv2; print(torch.__version__)'
export nnUNet_preprocessed=/root/autodl-tmp/nnUNet/nnUNet_preprocessed
export nnUNet_raw=/root/autodl-tmp/nnUNet/nnUNet_raw
export nnUNet_results=/root/autodl-tmp/nnUNet/nnUNet_results
python install.py
CUDA_VISIBLE_DEVICES=0 python benchmark.py
CUDA_VISIBLE_DEVICES=0 bash train.sh 0
```

If `nnunetv2` is missing in that environment, install your existing checkout
there with `python -m pip install -e /root/nnUNet --no-deps`; then retry the
import check. Do not replace a working Mamba environment with the base conda
environment that has an incompatible `mamba_ssm` package.

Other folds: `bash train.sh 1` through `bash train.sh 4`. Resume this trainer
only: `bash train.sh 0 --c`. The distinct trainer name creates a separate
nnU-Net results directory. Prediction must specify
`-tr nnUNetTrainer_SegMambaV2_1000ep -p nnUNetPlans`.

Only static checks ran in the current workspace, which has no PyTorch/GPU.
The benchmark verifies actual forward/backward and GPU memory on your system.
