"""Official SegMamba-V2 colorectal network on MRISegmenter via nnU-Net v2.

Uses the original network module without architectural edits. Reproduces its
SGD + CE + per-update polynomial scheduler within nnU-Net's shared data setup.
"""
import os

import torch
from torch import nn
from torch.optim import SGD
from torch.optim.lr_scheduler import LambdaLR

from nnunetv2.training.nnUNetTrainer.nnUNetTrainer import nnUNetTrainer
from nnunetv2.training.nnUNetTrainer._segmambav2_original.segmambav2 import SegMamba


class SegMambaV2CrossEntropy(nn.Module):
    """Original CrossEntropyLoss with nnU-Net's singleton target axis removed."""
    def __init__(self):
        super().__init__()
        self.ce = nn.CrossEntropyLoss()

    def forward(self, logits, target):
        return self.ce(logits, target[:, 0].long())


class nnUNetTrainer_SegMambaV2_1000ep(nnUNetTrainer):
    @staticmethod
    def build_network_architecture(
        plans_manager, configuration_manager, num_input_channels,
        num_output_channels, enable_deep_supervision=True,
    ):
        if (num_input_channels, num_output_channels) != (1, 63):
            raise ValueError('Expected one W input and 63 segmentation classes')
        return SegMamba(in_chans=num_input_channels, out_chans=num_output_channels)

    def _do_i_compile(self):
        # Mamba uses custom CUDA extensions; compile is opt-in because their
        # graph breaks/recompilation may be slower than eager execution.
        return self.device.type == 'cuda' and os.environ.get('nnUNet_compile', '').lower() in ('true', '1')

    def _build_loss(self):
        return SegMambaV2CrossEntropy()

    def configure_optimizers(self):
        optimizer = SGD(self.network.parameters(), lr=self.initial_lr,
                        momentum=0.99, nesterov=True, weight_decay=3e-5)
        total_updates = self.num_epochs * self.num_iterations_per_epoch
        scheduler = LambdaLR(
            optimizer,
            lr_lambda=lambda update: max(0.0, 1.0 - update / total_updates) ** 0.9,
        )
        return optimizer, scheduler

    def initialize(self):
        if self.was_initialized:
            raise RuntimeError('Trainer already initialized')
        if self.is_ddp:
            raise ValueError('This package targets one CUDA GPU')
        if self.configuration_name != '3d_fullres':
            raise ValueError('Use 3d_fullres')
        if tuple(self.configuration_manager.patch_size) != (48, 160, 192):
            raise ValueError('Expected the baseline patch (48,160,192)')
        if self.configuration_manager.batch_size != 2:
            raise ValueError('Expected batch_size=2')
        if self.label_manager.has_regions or self.label_manager.ignore_label is not None:
            raise ValueError('Expected mutually exclusive labels without ignore label')
        if self.label_manager.num_segmentation_heads != 63:
            raise ValueError('Expected 63 segmentation heads including background')

        self.enable_deep_supervision = False  # official network has one head
        self.num_epochs = 1000
        self.num_iterations_per_epoch = 250
        self.num_val_iterations_per_epoch = 50
        self.initial_lr = 1e-2
        self.weight_decay = 3e-5
        self.save_every = 50
        super().initialize()
        if not isinstance(self.optimizer, SGD) or not isinstance(self.loss, SegMambaV2CrossEntropy):
            raise RuntimeError('The original SGD/CE recipe was not installed')
        self.print_to_log_file(
            'SegMamba-V2 colorectal architecture: W-only; 63 logits; '
            'depths=(2,2,2,2); widths=(48,96,192,384); hidden_size=768; '
            'patch=(48,160,192); batch=2; 1000 epochs, 250 train/50 val; '
            'SGD lr=0.01 momentum=0.99 Nesterov, wd=3e-5; '
            'CE; polynomial lr per update, exponent=0.9; '
            'AMP on CUDA, clip norm=12, no deep supervision; '
            f'torch.compile={self._do_i_compile()}; '
            f'parameters={sum(p.numel() for p in self.network.parameters()):,}'
        )

    def on_train_epoch_start(self):
        # The base trainer steps LR once per epoch. The source trainer steps
        # after every batch, so avoid the base implementation here.
        self._updates_this_epoch = 0
        self.network.train()
        lr = float(self.optimizer.param_groups[0]['lr'])
        self.print_to_log_file('')
        self.print_to_log_file(f'Epoch {self.current_epoch}')
        self.print_to_log_file(f'Current learning rate: {lr:.8f}')
        self.logger.log('lrs', lr, self.current_epoch)

    def train_step(self, batch: dict) -> dict:
        data = batch['data'].to(self.device, non_blocking=True)
        target = batch['target']
        if isinstance(target, (tuple, list)):
            raise ValueError('Deep supervision targets are not expected')
        target = target.to(self.device, non_blocking=True)
        self.optimizer.zero_grad(set_to_none=True)
        with torch.autocast('cuda', enabled=self.device.type == 'cuda'):
            logits = self.network(data)
            loss = self.loss(logits, target)
        if not torch.isfinite(loss).item():
            raise FloatingPointError(f'Nonfinite training loss at epoch {self.current_epoch}')
        if self.grad_scaler is not None:
            self.grad_scaler.scale(loss).backward()
            self.grad_scaler.unscale_(self.optimizer)
            torch.nn.utils.clip_grad_norm_(self.network.parameters(), 12)
            self.grad_scaler.step(self.optimizer)
            self.grad_scaler.update()
        else:
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.network.parameters(), 12)
            self.optimizer.step()
        self._updates_this_epoch += 1
        absolute_update = self.current_epoch * self.num_iterations_per_epoch + self._updates_this_epoch
        self.lr_scheduler.step(absolute_update)
        return {'loss': loss.detach().cpu().numpy()}

    def set_deep_supervision_enabled(self, enabled: bool):
        self.enable_deep_supervision = False
