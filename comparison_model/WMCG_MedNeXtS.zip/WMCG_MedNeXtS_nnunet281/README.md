# WMCG-sFB + MedNeXt-S on MRISegmenter with nnU-Net 2.8.1

This is an adapter of the author's uploaded `WMCSFB-main.zip`, **not** a replacement of the MedNeXt-S backbone with nnU-Net's U-Net. It uses the author's `MedNextV1.py`, `blocks_fb.py`, `create_mednext_v1.py`, `conv3d_sfb.py`, and bundled `spherical_bessel.npy`. The model is MedNeXt-S-k5 (base channels 32, expansion 2, two blocks at each of nine stages) with WMCG-sFB depthwise convolutions in its ordinary residual blocks. Native down/up blocks remain unchanged. The author's released `MedNextV1.py` actually forces its output to be a single logits tensor; the trainer therefore disables nnU-Net deep supervision so loss and targets agree. Original auxiliary output heads remain registered as in the uploaded model.

Only import paths, the machine-specific basis file/cache paths, and safe CPU tensor loading changed in the bundled model source. The NumPy/SciPy basis mathematics, kernel weights, topology, and native stride-2 blocks have not been changed. Reusing nnU-Net's preprocessing, augmentation, optimizer, inference, and evaluation differs from running the authors' complete old experimental pipeline; state this in the Methods section.

## Server setup

Unzip this directory to `/root/WMCG_MedNeXtS_nnunet281`. Use the **same** Python environment in which `nnunetv2==2.8.1`, PyTorch, NumPy, and SciPy are installed. Do not install the uploaded old nnU-Net fork. `pip install -e .` below installs only this adapter; `--no-deps` prevents replacing the installed nnU-Net.

```bash
cd /root/WMCG_MedNeXtS_nnunet281
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1 NUMEXPR_MAX_THREADS=1
export nnUNet_raw=/root/autodl-tmp/nnUNet/nnUNet_raw
export nnUNet_preprocessed=/root/autodl-tmp/nnUNet/nnUNet_preprocessed
export nnUNet_results=/root/autodl-tmp/nnUNet/nnUNet_results
export WMCG_SFB_CACHE=/root/autodl-tmp/nnUNet/wmcg_sfb_cache
export nnUNet_compile=False

python -m pip install --no-deps --no-build-isolation -e .
python install.py
python -c 'import nnunetv2, importlib.metadata; print(nnunetv2.__file__, importlib.metadata.version("nnunetv2"))'
```

`install.py` installs the custom Trainer into the active nnU-Net installation. It refuses to overwrite a different Trainer of the same name. Repeat the installation if the server environment or nnU-Net installation changes. The basis cache is generated once for each distinct filter shape and reused on subsequent folds. The first invocation can take longer during model construction. Keep `WMCG_SFB_CACHE` stable for all five folds and inference.

## Existing plans and split checks

The commands below use the existing single-W dataset and `splits_final.json` directly. Verify that `Dataset129_1CH` is the dataset on which the baseline was trained and its input images follow nnU-Net's `_0000.nii.gz` naming. Individual ART/DEL/PRE/VEN cases remain independent. No cross-phase sampling is performed.

```bash
cd /root/WMCG_MedNeXtS_nnunet281
python preflight.py \
  --raw "$nnUNet_raw/Dataset129_1CH" \
  --preprocessed "$nnUNet_preprocessed/Dataset129_1CH" \
  --expected-patch 48 160 192
python smoke.py --patch 16 32 32 --batch-size 2
```

The plan must have `batch_size=2` and `patch_size=[48,160,192]`. This native MedNeXt architecture downsamples each axis four times, so each patch dimension must be divisible by 16. If your nnU-Net plan uses a different patch, the preflight script stops; assess the difference before editing a plan. **A successful small smoke test does not establish that the full patch fits a 31.36 GiB GPU.** The 63-class output may consume more memory than the paper's datasets.

Optional full-patch forward/backward probe (may run out of memory):

```bash
CUDA_VISIBLE_DEVICES=0 python smoke.py \
  --patch 48 160 192 --batch-size 2 --num-classes 63
```

The nnU-Net training step also contains data augmentation, loss computation and optimizer state. If this probe passes, measure one actual fold before starting all five. If it runs out of memory, stop; shrinking the patch changes the comparison and is an explicit experimental choice.

## Training

nnU-Net 2.8.1 reads the existing `Dataset129_1CH/splits_final.json`. This Trainer fixes **1000 epochs, 250 train iterations, 50 validation iterations per epoch**; batch 2 and patch dimensions are read from the existing `nnUNetPlans.json`. The first command starts a real fold; interrupt it after its first epoch if a timing-only probe is required. To resume, use `--c` rather than starting over. The model and its source need to be importable from the same Python environment in training and prediction.

```bash
CUDA_VISIBLE_DEVICES=0 nnUNetv2_train 129 3d_fullres 0 \
  -tr nnUNetTrainerWMCGsFBMedNeXtS

# Resume fold 0 if interrupted:
CUDA_VISIBLE_DEVICES=0 nnUNetv2_train 129 3d_fullres 0 \
  -tr nnUNetTrainerWMCGsFBMedNeXtS --c

# After checking the first fold, train only the remaining folds:
for fold in 1 2 3 4; do
  CUDA_VISIBLE_DEVICES=0 nnUNetv2_train 129 3d_fullres "$fold" \
    -tr nnUNetTrainerWMCGsFBMedNeXtS || exit 1
done
```

If `nnUNet_compile=False` is changed to `True`, record it and first check that compilation and prediction succeed with the author's custom convolution. The initial commands disable compilation to keep the first run diagnosable. nnU-Net's default learning rate, loss and augmentations are used. Its validation log Dice is a patch-sampling estimate; use the official test-set evaluation for the performance table.

## Five-fold ensemble inference (TTA disabled)

Run after **all** `checkpoint_final.pth` files exist. The input folder should contain W volumes named `test_XXX_PHASE_0000.nii.gz`, and `labelsTs` should have corresponding `test_XXX_PHASE.nii.gz` names. Set `--disable_tta` on all compared models when your table uses no TTA.

```bash
PRED=/root/autodl-tmp/nnUNet/test_predictions/WMCGsFB_MedNeXtS_5fold_noTTA

CUDA_VISIBLE_DEVICES=0 nnUNetv2_predict \
  -i "$nnUNet_raw/Dataset129_1CH/imagesTs" \
  -o "$PRED" \
  -d 129 -c 3d_fullres \
  -tr nnUNetTrainerWMCGsFBMedNeXtS \
  -f 0 1 2 3 4 --disable_tta

nnUNetv2_evaluate_folder \
  "$nnUNet_raw/Dataset129_1CH/labelsTs" "$PRED" \
  -djfile "$nnUNet_raw/Dataset129_1CH/dataset.json" \
  -pfile "$nnUNet_preprocessed/Dataset129_1CH/nnUNetPlans.json"
```

The expected experiment label in your paper is **WMCG-sFB (MedNeXt-S backbone; nnU-Net v2.8.1 pipeline)**. It is neither an original nnU-Net backbone nor an independent new 2026 encoder-decoder. Compare the five-fold ensemble against nnU-Net using the **same cases, W input, test labels, evaluation script, and TTA choice**; note any different patch size and the lack of deep supervision. The released code is provided in the accompanying archive as provenance.

## Verification scope

Locally verified: archive integrity, Python syntax, bundled source relationships, and availability of the author's basis asset. A CUDA end-to-end training/inference run must be completed on the server: this packaging environment has no PyTorch or nnU-Net installation and no GPU.
