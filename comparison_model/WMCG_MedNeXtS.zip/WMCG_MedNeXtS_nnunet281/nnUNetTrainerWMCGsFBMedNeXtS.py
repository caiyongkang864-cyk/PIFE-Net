"""nnU-Net 2.8.1 adapter for the author's WMCG-sFB + MedNeXt-S-k5 model.

This file is installed into nnunetv2/training/nnUNetTrainer/variants/network_architecture.
It deliberately does not import the original 2024 nnU-Net fork.
"""

from pathlib import Path

import torch

from nnunetv2.training.nnUNetTrainer.nnUNetTrainer import nnUNetTrainer
from wmcg_mednext.create_mednext_v1 import create_mednextv1_small


class nnUNetTrainerWMCGsFBMedNeXtS(nnUNetTrainer):
    def __init__(self, plans: dict, configuration: str, fold: int,
                 dataset_json: dict, device: torch.device = torch.device('cuda')):
        super().__init__(plans, configuration, fold, dataset_json, device)
        # The released MedNextV1.py unconditionally disables deep supervision.
        # Align nnU-Net's target and loss with its actual single-output forward.
        self.enable_deep_supervision = False
        self.num_epochs = 1000
        self.num_iterations_per_epoch = 250
        self.num_val_iterations_per_epoch = 50

    @staticmethod
    def build_network_architecture(plans_manager, configuration_manager,
                                   num_input_channels: int, num_output_channels: int,
                                   enable_deep_supervision: bool = True):
        patch = tuple(configuration_manager.patch_size)
        if len(patch) != 3 or any(p % 16 for p in patch):
            raise ValueError(
                f'MedNeXt-S has four native x2 downsamplings: 3D patch '
                f'dimensions must be divisible by 16, got {patch}. '
                'This adapter does not alter the architecture or plans.')
        if num_input_channels != 1:
            raise ValueError(f'Expected one W input channel, got {num_input_channels}')
        if enable_deep_supervision:
            raise ValueError('The released WMCG MedNextV1.py returns a single output. '
                             'Use this trainer with deep supervision disabled.')
        return create_mednextv1_small(num_input_channels, num_output_channels,
                                       kernel_size=5, ds=False)

    def set_deep_supervision_enabled(self, enabled: bool):
        # nnU-Net may toggle this for full-volume validation. Never activate it:
        # the released model has a single-output forward.
        if enabled:
            raise RuntimeError('WMCG-sFB + MedNeXt-S release supports one output only')
        return super().set_deep_supervision_enabled(False)
