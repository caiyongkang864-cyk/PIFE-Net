"""Install the trainer into the active nnU-Net 2.8.1 installation."""

import importlib.metadata
import shutil
from pathlib import Path

import nnunetv2
import wmcg_mednext


def main():
    version = importlib.metadata.version('nnunetv2')
    if version != '2.8.1':
        raise RuntimeError(f'This adapter targets nnunetv2 2.8.1; installed: {version}')
    src = Path(__file__).resolve().parent / 'nnUNetTrainerWMCGsFBMedNeXtS.py'
    dst = (Path(nnunetv2.__file__).resolve().parent / 'training' / 'nnUNetTrainer'
           / 'variants' / 'network_architecture' / src.name)
    if not dst.parent.is_dir():
        raise RuntimeError(f'Trainer variants directory missing: {dst.parent}')
    if dst.exists() and dst.read_bytes() != src.read_bytes():
        raise RuntimeError(f'Existing trainer differs; inspect before replacing: {dst}')
    shutil.copyfile(src, dst)
    print(f'Installed: {dst}')
    print(f'Model source: {Path(wmcg_mednext.__file__).resolve().parent}')


if __name__ == '__main__':
    main()
