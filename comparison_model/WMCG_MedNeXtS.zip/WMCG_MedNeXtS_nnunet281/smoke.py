"""Test native WMCG-sFB + MedNeXt-S forward and backward on the server GPU."""

import argparse
import torch
from wmcg_mednext.create_mednext_v1 import create_mednextv1_small


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--patch', nargs=3, type=int, default=[16, 32, 32])
    ap.add_argument('--batch-size', type=int, default=2)
    ap.add_argument('--num-classes', type=int, default=63)
    args = ap.parse_args()
    if any(n % 16 for n in args.patch):
        raise ValueError('Four native downsamplings require multiples of 16')
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    net = create_mednextv1_small(1, args.num_classes, kernel_size=5, ds=False).to(device)
    net.train()
    x = torch.randn(args.batch_size, 1, *args.patch, device=device)
    y = torch.randint(args.num_classes, (args.batch_size, *args.patch), device=device)
    if device.type == 'cuda':
        torch.cuda.reset_peak_memory_stats()
    with torch.autocast(device_type=device.type, enabled=device.type == 'cuda'):
        logits = net(x)
        if not isinstance(logits, torch.Tensor) or logits.shape != (args.batch_size, args.num_classes, *args.patch):
            raise RuntimeError(f'Unexpected model output: {type(logits)} {getattr(logits, "shape", "")}')
        loss = torch.nn.functional.cross_entropy(logits.float(), y)
    loss.backward()
    mem = (f' peak_GiB={torch.cuda.max_memory_allocated() / 2**30:.2f}'
           if device.type == 'cuda' else '')
    print(f'PASS shape={tuple(logits.shape)} loss={loss.detach().item():.4f}{mem}')


if __name__ == '__main__':
    main()
