Source: user-provided `WMCSFB-main.zip` (archive comment/commit `077e652dceb24bd43075b53c145c1c4eeac3570e`).

Files bundled from `WMCSFB-main/nnUNet/nnunetv2/utilities`:

| Bundled file | Original location | Changes |
| --- | --- | --- |
| `MedNextV1.py` | `mednextv1/MedNextV1.py` | import path only |
| `blocks_fb.py` | `mednextv1/blocks_fb.py` | import path only |
| `create_mednext_v1.py` | `mednextv1/create_mednext_v1.py` | import path only |
| `conv3d_sfb.py` | `dynamic_network_architectures2305/building_blocks/conv3d_sfb.py` | original host paths replaced by package asset/cache; tensor loading restricted to weights |
| `spherical_bessel.npy` | `WMCSFB-main/nnUNet/weightsFB23/spherical_bessel.npy` | byte-for-byte identical, SHA256 `4efef848c2536e13b719047cf683ba9222eedf142c19b70c8b966e0973e3a947` |

The nnU-Net 2.8.1 trainer, installer, preflight, and smoke scripts are integration code. The original old nnU-Net source tree is intentionally not installed.
