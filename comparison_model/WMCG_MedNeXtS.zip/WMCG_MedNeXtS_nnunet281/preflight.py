"""Check the MRISegmenter dataset and nnU-Net plans without modifying them."""

import argparse
import json
from pathlib import Path

import nnunetv2
from importlib.metadata import version


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--raw', type=Path, required=True, help='Dataset129_1CH in nnUNet_raw')
    ap.add_argument('--preprocessed', type=Path, required=True,
                    help='Dataset129_1CH in nnUNet_preprocessed')
    ap.add_argument('--expected-patch', nargs=3, type=int, default=[48, 160, 192])
    args = ap.parse_args()
    assert version('nnunetv2') == '2.8.1', version('nnunetv2')
    dataset = json.loads((args.raw / 'dataset.json').read_text())
    plans = json.loads((args.preprocessed / 'nnUNetPlans.json').read_text())
    splits = json.loads((args.preprocessed / 'splits_final.json').read_text())
    cfg = plans['configurations']['3d_fullres']
    channels = dataset.get('channel_names', dataset.get('modality', {}))
    labels = dataset['labels']
    patch = cfg['patch_size']
    print('nnU-Net:', version('nnunetv2'), 'at', nnunetv2.__file__)
    print('channels:', channels, 'label count:', len(labels),
          'batch:', cfg['batch_size'], 'patch:', patch)
    if len(channels) != 1 or str(channels.get('0', '')).lower() not in ('w', 't1w-fs', 't1w_fs'):
        raise ValueError('Expected exactly one W image channel; inspect dataset.json')
    if len(labels) != 63 or sorted(int(x) for x in labels.values()) != list(range(63)):
        raise ValueError('Expected class IDs 0..62 (63 output heads)')
    if cfg['batch_size'] != 2:
        raise ValueError('Plans batch_size must be 2; set it in a dedicated plans variant')
    if list(patch) != list(args.expected_patch):
        raise ValueError(f'Plans patch {patch} differs from requested {args.expected_patch}')
    if any(p % 16 for p in patch):
        raise ValueError(f'MedNeXt-S requires all patch dimensions divisible by 16: {patch}')
    if len(splits) != 5:
        raise ValueError('Expected 5 existing folds')
    for i, split in enumerate(splits):
        tr, val = set(split['train']), set(split['val'])
        if tr & val:
            raise ValueError(f'Fold {i}: train/val overlap: {tr & val}')
        print(f'fold {i}: train={len(tr)} val={len(val)}')
    print('PASS: original plans and splits can be reused')


if __name__ == '__main__':
    main()
